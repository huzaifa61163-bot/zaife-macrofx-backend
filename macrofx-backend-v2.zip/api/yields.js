// GET /api/yields
// Source: FRED (Federal Reserve Bank of St. Louis) — official US Treasury data.
// Series: DGS2 (2-Year), DGS10 (10-Year). FRED updates once per business day.

const { setCors, cacheGet, cacheSet, errorResponse, unavailableResponse } = require("../lib/util");

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

async function fetchSeries(seriesId, apiKey) {
  const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${apiKey}&file_type=json&sort_order=desc&limit=10`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`FRED request failed for ${seriesId}: ${r.status}`);
  const data = await r.json();
  const obs = (data.observations || []).filter((o) => o.value !== ".");
  if (obs.length === 0) throw new Error(`No usable observations for ${seriesId}`);
  return obs; // newest first
}

module.exports = async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(200).end();

  const apiKey = process.env.FRED_API_KEY;
  if (!apiKey) {
    return res.status(200).json(unavailableResponse("FRED_API_KEY is not set on the server. Add it in Vercel → Settings → Environment Variables."));
  }

  const cached = cacheGet("yields", CACHE_TTL_MS);
  if (cached) return res.status(200).json(cached);

  try {
    const [twoYear, tenYear] = await Promise.all([
      fetchSeries("DGS2", apiKey),
      fetchSeries("DGS10", apiKey),
    ]);

    const latest2y = parseFloat(twoYear[0].value);
    const prev2y = parseFloat(twoYear[1]?.value ?? twoYear[0].value);
    const latest10y = parseFloat(tenYear[0].value);
    const prev10y = parseFloat(tenYear[1]?.value ?? tenYear[0].value);

    const payload = {
      status: "live",
      source: "FRED (Federal Reserve Bank of St. Louis)",
      fetchedAt: new Date().toISOString(),
      us2y: {
        value: latest2y,
        change: +(latest2y - prev2y).toFixed(3),
        observedAt: twoYear[0].date,
        seriesId: "DGS2",
        history: twoYear.slice(0, 7).reverse().map((o) => parseFloat(o.value)),
      },
      us10y: {
        value: latest10y,
        change: +(latest10y - prev10y).toFixed(3),
        observedAt: tenYear[0].date,
        seriesId: "DGS10",
        history: tenYear.slice(0, 7).reverse().map((o) => parseFloat(o.value)),
      },
      spread2s10s: +(latest10y - latest2y).toFixed(3),
    };

    cacheSet("yields", payload);
    return res.status(200).json(payload);
  } catch (err) {
    return res.status(200).json(errorResponse(err.message, "FRED_FETCH_FAILED"));
  }
};
