# MacroFX Backend v2 — Corrected Setup Guide

## Why you got 404 last time

The most common cause of "deployment says Ready but every URL 404s" is that
the files ended up **one folder too deep** in GitHub — e.g. GitHub stored
`macrofx-backend/api/yields.js` instead of `api/yields.js` at the **root** of
the repository. Vercel only auto-detects an `api/` folder if it sits at the
project root. This guide fixes that specifically in Step 2.

---

## STEP 1 — Get your 3 free API keys (skip if you already have them)

- **FRED**: https://fred.stlouisfed.org/docs/api/api_key.html
- **Twelve Data**: https://twelvedata.com/pricing → Free plan → Dashboard → API key
- **Financial Modeling Prep**: https://site.financialmodelingprep.com/developer/docs/pricing → Free plan → Dashboard → API key

Keep them saved somewhere private (Notes app). Don't paste them anywhere yet.

---

## STEP 2 — Upload to GitHub the CORRECT way

1. Go to https://github.com and open (or create) a **private** repository, e.g. `macrofx-backend`
2. If you already have one from before, **delete it and create a fresh one** — this avoids leftover nested files causing the same 404 again.
3. On the empty repo page, click **"uploading an existing file"**
4. **Important — do this part carefully:**
   - Open the `macrofx-backend` folder on your device (the one from this ZIP, already unzipped)
   - Select **everything inside it** — `api`, `lib`, `public`, `package.json`, `vercel.json`, `.env.example` — all at once
   - Drag **those selected items** into GitHub's upload box
   - **Do NOT drag the outer `macrofx-backend` folder itself** — only what's inside it
5. Click **Commit changes**
6. Confirm the repo now shows `api`, `lib`, `public` etc. **directly in the file list** — not nested inside another folder called `macrofx-backend`

If you're not sure, click into the `api` folder on GitHub — you should see `yields.js`, `fx.js`, `calendar.js`, `health.js`, `economic-data.js` sitting there directly.

---

## STEP 3 — Deploy on Vercel

1. Go to https://vercel.com → **Add New → Project**
2. If your old project from before still exists, **delete it first** (Project → Settings → scroll down → Delete Project) to avoid stale config
3. Import the `macrofx-backend` repo fresh
4. Before deploying, check **"Root Directory"** in the import screen — it should say `.` (the repo root). If it shows a subfolder name, click Edit and set it back to `.`
5. Add the 3 environment variables (Settings → Environment Variables, or during import):

   | Name | Value |
   |---|---|
   | `FRED_API_KEY` | *(your FRED key)* |
   | `TWELVEDATA_API_KEY` | *(your Twelve Data key)* |
   | `FMP_API_KEY` | *(your FMP key)* |

6. Click **Deploy**

---

## STEP 4 — Test it, in this exact order

1. Open your new Vercel URL directly in the browser, e.g. `https://your-project.vercel.app`
   → You should see a simple dark page titled **"MacroFX Backend — Deployed ✓"** (not a 404)
2. Then open `https://your-project.vercel.app/api/health`
   → You should see JSON: `{"status":"ok", ...}`
3. If both of those work, try `https://your-project.vercel.app/api/yields`
   → Should return live yield data if `FRED_API_KEY` is set correctly, or a clean `"unavailable"`/`"error"` JSON message if not — never a 404.

If Step 4.1 or 4.2 still 404s, the folder structure issue from Step 2 is almost certainly still present — go back and check the file list on GitHub directly.

---

## Route reference

| Route | Source | Purpose |
|---|---|---|
| `/api/health` | — | Deployment + key-configuration check |
| `/api/yields` | FRED | US 2Y, 10Y Treasury yields + 2s10s spread |
| `/api/fx` | Twelve Data | Live spot rates for all 7 pairs |
| `/api/calendar` | Financial Modeling Prep | CPI/NFP/GDP/etc. previous, forecast, actual |
| `/api/economic-data?indicator=...` | FRED | Fed Funds rate, Core PCE, unemployment, GDP (used by the Central Bank Fed card) |

Nothing in the frontend needs to change — the routes it already calls
(`/api/yields`, `/api/fx-rates` → now `/api/fx`, `/api/calendar`,
`/api/economic-data`, `/api/health`) match this backend. If you're using the
frontend file from the previous message, note it currently calls
`/api/fx-rates` — that one route name changed to `/api/fx` in this rebuild.
Say the word and I'll update just that one line in the frontend to match.
