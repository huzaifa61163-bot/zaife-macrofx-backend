// GET /api/fx
// Source: Twelve Data — free tier: 8 requests/minute, 800/day.
// All 7 instruments are fetched in ONE request (comma-separated symbols).

const { setCors, cacheGet, cacheSet, errorResponse, unavailableResponse } = require("../lib/util");

const CACHE_TTL_MS = 45 * 1000; // 45 seconds

const SYMBOLS = ["USD/JPY", "EUR/USD", "GBP/USD", "XAU/USD", "USD/CHF", "AUD/USD", "USD/CAD"];

module.exports = async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") return res.status(200).end();

  const apiKey = process.env.TWELVEDATA_API_KEY;
  if (!apiKey) {
    return res.status(200).json(unavailableResponse("TWELVEDATA_API_KEY is not set on the server."));
  }

  const cached = cacheGet("fx", CACHE_TTL_MS);
  if (cached) return res.status(200).json(cached);

  try {
    const symbolParam = encodeURIComponent(SYMBOLS.join(","));
    const url = `https://api.twelvedata.com/quote?symbol=${symbolParam}&apikey=${apiKey}`;
    const r = await fetch(url);
    if (!r.ok) throw new Error(`Twelve Data request failed: ${r.status}`);
    const data = await r.json();

    // Twelve Data returns a single object for 1 symbol, or an object keyed
    // by symbol for multiple symbols. Normalize both shapes.
    const bySymbol = SYMBOLS.length === 1 ? { [SYMBOLS[0]]: data } : data;

    const rates = {};
    for (const sym of SYMBOLS) {
      const entry = bySymbol[sym];
      if (!entry || entry.status === "error" || !entry.close) {
        rates[sym] = { status: "error", error: entry?.message || "No data returned" };
        continue;
      }
      rates[sym] = {
        status: "live",
        value: parseFloat(entry.close),
        change: entry.change ? parseFloat(entry.change) : null,
        percentChange: entry.percent_change ? parseFloat(entry.percent_change) : null,
        observedAt: entry.datetime || null,
      };
    }

    const payload = {
      status: "live",
      source: "Twelve Data",
      fetchedAt: new Date().toISOString(),
      rates,
    };
    cacheSet("fx", payload);
    return res.status(200).json(payload);
  } catch (err) {
    return res.status(200).json(errorResponse(err.message, "TWELVEDATA_FETCH_FAILED"));
  }
};
